defmodule UploaderGWeb.TransmissionLive.Paginator do
  use UploaderGWeb, :live_component

  alias UploaderG.Entities
end
