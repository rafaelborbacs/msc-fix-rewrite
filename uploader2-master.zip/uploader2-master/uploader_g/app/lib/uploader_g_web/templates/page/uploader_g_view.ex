defmodule UploaderGWeb.UploaderTView do
  use UploaderGWeb, :view
end
