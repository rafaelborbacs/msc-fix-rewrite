defmodule UploaderGWeb.PageView do
  use UploaderGWeb, :view
end
