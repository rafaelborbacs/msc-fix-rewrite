defmodule UploaderGWeb.UploaderGView do
  use UploaderGWeb, :view
end
