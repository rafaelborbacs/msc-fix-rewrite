defmodule UploaderG.Mailer do
  use Swoosh.Mailer, otp_app: :uploader_g
end
