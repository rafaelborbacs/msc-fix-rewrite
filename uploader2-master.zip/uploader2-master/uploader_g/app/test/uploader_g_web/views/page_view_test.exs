defmodule UploaderGWeb.PageViewTest do
  use UploaderGWeb.ConnCase, async: true
end
