ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(UploaderG.Repo, :manual)
