defmodule UploaderRWeb.PageViewTest do
  use UploaderRWeb.ConnCase, async: true
end
