defmodule UploaderR.Mailer do
  use Swoosh.Mailer, otp_app: :uploader_r
end
