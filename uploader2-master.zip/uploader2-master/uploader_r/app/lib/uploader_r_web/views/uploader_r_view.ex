defmodule UploaderRWeb.UploaderRView do
  use UploaderRWeb, :view
end
