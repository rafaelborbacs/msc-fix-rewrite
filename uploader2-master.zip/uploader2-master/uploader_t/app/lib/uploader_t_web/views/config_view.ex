defmodule UploaderTWeb.ConfigView do
  use UploaderTWeb, :view
  alias UploaderTWeb.ConfigView

  def render("index.json", %{json: json}) do
    json
  end
end
