defmodule UploaderTWeb.UIView do
  use UploaderTWeb, :view
end
