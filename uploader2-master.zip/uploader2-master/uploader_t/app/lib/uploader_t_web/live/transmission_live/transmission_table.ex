defmodule UploaderTWeb.TransmissionLive.TransmissionTable do
  use UploaderTWeb, :live_component

  alias UploaderT.Operation
end
