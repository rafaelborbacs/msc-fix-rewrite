defmodule UploaderT.Mailer do
  use Swoosh.Mailer, otp_app: :uploader_t
end
