ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(UploaderT.Repo, :manual)
