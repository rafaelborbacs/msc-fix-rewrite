defmodule UploaderTWeb.PageViewTest do
  use UploaderTWeb.ConnCase, async: true
end
